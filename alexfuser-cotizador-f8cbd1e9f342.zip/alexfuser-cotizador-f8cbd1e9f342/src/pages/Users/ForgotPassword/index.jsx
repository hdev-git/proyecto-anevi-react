import React from 'react';

export default function ForgotPassword() {


  return (
    <>
      Forgot Pass
    </>
  );
}