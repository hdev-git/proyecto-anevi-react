const { response } = require("express");
const { pool } = require("../database");

function listMail(params) {}
module.exports = { listMail };
